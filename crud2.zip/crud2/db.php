<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'lojinha';

$conn = mysqli_connect($servername,$username,$password,$database);
// if($conn){
// //     die("conexao: F". mysqli_connect_error());
// // }
?>