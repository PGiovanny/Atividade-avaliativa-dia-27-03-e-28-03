<h1>novo cadastro</h1>
<form action ="?page=salvar" method="post" >
    <input type="hidden" name="acao" value="cadastrar"          >
    <div>
        <label >Nome</label>
        <input type="text" name="nome" class= "form-control" >
    </div>
    <div>
        <label >Fabricante</label>
        <input type="text" name="fabricante" class= "form-control" >
    </div>
    <div>
        <label >Descrição</label>
        <input type="text" name="descricao" class= "form-control" >
    </div>
    <div>
        <label >Quantidade</label>
        <input type="text" name="quantidade" class= "form-control" >
    </div>
    <div class="md-3">
        <button type="submit" class=" bnt-primary">Enviar</button>

    </div>
   
   
   

</form>