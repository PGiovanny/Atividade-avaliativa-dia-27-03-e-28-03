<h1>Editar  cadastro</h1>
<?php
    $slq = "SELECT * FROM dados  WHERE codigo=".$_REQUEST["codigo"];
    $res = $conn->query($slq);
    $row = $res->fetch_object();

?>
<form action ="?page=salvar" method="post" >
    <input type="hidden" name="acao" value="editar"          >
    <input type="hidden" name="codigo" value="<?php print $row->codigo   ?>"          >

    <div>
        <label >Nome</label>
        <input type="text" name="nome" value="<?php print $row->nome; ?>" class= "form-control" >
    </div>
    <div>
        <label >Fabricante</label>
        <input type="text" name="fabricante" value="<?php print $row->fabricante; ?>" class= "form-control" >
    </div>
    <div>
        <label >Descrição</label>
        <input type="text" name="descricao" value="<?php print $row->descricao; ?>" class= "form-control" >
    </div>
    <div>
        <label >Quantidade</label>
        <input type="text" name="quantidade" value="<?php print $row->quantidade; ?>" class= "form-control" >
    </div>
    <div class="md-3">
        <button type="submit" class=" bnt-primary">Enviar</button>

    </div>
   
   
   

</form>
